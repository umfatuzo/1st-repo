#include <iostream>

using namespace std;

int main()
{
    double workHours, hourPayRate, grossPay;
    cout << "Enter a working hours - between 0 to 60\n";
    cin >> workHours;
    if (workHours > 0 && workHours <= 60)
    {
      cout << "Enter Hourly pay rate ";

      cin >> hourPayRate;
      if (workHours <= 40) //these are regular hours
        grossPay = workHours * hourPayRate;
        else //overtime
        grossPay = 40 * hourPayRate + (workHours - 40) * hourPayRate * 1.5;
        cout << "The Employee's weekly payment is " << grossPay << endl;

    }
    else
        cout << "Invalid input. Enter workhours between 0 and 60\n";

    return 0;
}
